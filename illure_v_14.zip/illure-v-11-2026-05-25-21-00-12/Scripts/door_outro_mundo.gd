extends Area2D

var player_inside = false
var irmao_inside = false

func _on_body_entered(body):

	if body.is_in_group("player"):
		player_inside = true

	if body.is_in_group("irmao"):
		irmao_inside = true


func _on_body_exited(body):

	if body.is_in_group("player"):
		player_inside = false

	if body.is_in_group("irmao"):
		irmao_inside = false


func _process(_delta):

	if (
		player_inside
		and irmao_inside
		and Input.is_action_just_pressed("ui_accept")
	):

		# Só entra no mundo perfeito se estiver na etapa correta
		if GameManager.etapa == 6:

			GameManager.porta_outro_mundo = true

			print("Entrando no mundo perfeito")

			GameManager.verificar_progresso()

			GameManager.portas_atravessadas += 1

			get_tree().change_scene_to_file("res://Scenes/outro_mundo.tscn")
