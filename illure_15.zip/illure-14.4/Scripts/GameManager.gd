extends Node

signal objetivo_concluido
signal etapa_mudou(nova_etapa)
signal mostrar_ajuda
var outra_mae
var outro_pai
var falou_mae_etapa_2 = false

@onready var area_dialogo_pai = get_tree().get_first_node_in_group("dialogo_pai")

var objetivos

func _ready():
	await get_tree().process_frame

	objetivos = get_tree().get_first_node_in_group("objetivos")

	if objetivos == null:
		print("WARNING: objetivos não encontrado no _ready")
	
	outra_mae = get_tree().get_first_node_in_group("outra_mae")
	outro_pai = get_tree().get_first_node_in_group("outro_pai")

	#if debug_mode:
		#etapa = debug_start_etapa
		#verificar_progresso()
	#else:
		#etapa = 0
		#verificar_progresso()

	#print("Iniciou na etapa:", etapa)

	#print(objetivos)
# ==================================================
# CONTROLE GLOBAL
# ==================================================

# ==================================================
# ESTATÍSTICAS
# ==================================================
var total_objetos_coletaveis := 20

var debug_mode := true
#var debug_start_etapa := 0

var tempo_total := 0.0
var objetos_encontrados := 0
var portas_atravessadas := 0
var distancia_andada := 0.0
var final_alcancado := ""

var etapa = 0
var em_dialogo = false
var cena_atual = ""
var encontrou_porta = false
var abriu_porta = false
var porta_outro_mundo = false
var falar_outra_mae = false
var falar_outro_pai = false
var encontrou_gato = false
var encontrou_porta_secreta = false
var pais_perseguem = false
var falou_com_gato_final = false
var pais_apareceram = false
var irmao_jogando_pedra = false
var dialogo_terminou = false
var player_pode_andar = false

# referências
var ultimo_checkpoint := ""
var tempo_salvo := 0.0
var ultima_posicao


func avancar_etapa(nova_etapa):

	if nova_etapa > etapa:

		etapa = nova_etapa

		print("ETAPA ATUAL:", etapa)

		emit_signal("etapa_mudou", etapa)
		
		verificar_progresso()
		

# ==================================================
# CONTROLE DE DIÁLOGO
# ==================================================
func iniciar_dialogo():
	em_dialogo = true

func encerrar_dialogo():
	em_dialogo = false

# ==================================================
# ITENS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

var foto_familia = false
var caderno_lina = false
var caixa_pai = false
var chave_porta = false
var foto_outra_familia = false
var caderno_outra_lina = false
var caixa_outro_pai = false
var quadro_sombrio = false
var urso_empalhado_sangrando = false
var olho_na_parede = false
var espelho_estranho = false

var boneca_quebrada = false
var ursinho_rasgado = false
var bilhetes_socorro = false
var sangue_chao = false
var objetos_tortura = false
var mesa_jantar = false

var confronto_pai = false
var confronto_mae = false
var esperar_porta_mae = false
var esperar_porta_pai = false
var pai_chegou_porta = false
var mae_chegou_porta = false
var entrou_no_porao = false

var falar_mae_etapa3 = false

var avançar_etapa_14 = false

# ==================================================
# RESET
# ==================================================
func novo_jogo():

	etapa = 0
	em_dialogo = false

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false
	chave_porta = false
	foto_outra_familia = false
	caderno_outra_lina = false
	caixa_outro_pai = false
	
	print("JOGO RESETADO")
	
func _process(delta):

	tempo_total += delta
# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista":
			if not item_lista:
				item_lista = true
				objetos_encontrados += 1

		"fita":
			if not item_fita:
				item_fita = true
				objetos_encontrados += 1

		"panela":
			if not item_panela:
				item_panela = true
				objetos_encontrados += 1

		"foto":
			if not foto_familia:
				foto_familia = true
				objetos_encontrados += 1

		"caderno":
			if not caderno_lina:
				caderno_lina = true
				objetos_encontrados += 1

		"caixa_pai":
			if not caixa_pai:
				caixa_pai = true
				objetos_encontrados += 1

		"chave":
			if not chave_porta:
				chave_porta = true
				objetos_encontrados += 1
				print("Pegou a chave")

		"foto_outro":
			if not foto_outra_familia:
				foto_outra_familia = true
				objetos_encontrados += 1

		"caderno_outro":
			if not caderno_outra_lina:
				caderno_outra_lina = true
				objetos_encontrados += 1

		"caixa_outro":
			if not caixa_outro_pai:
				caixa_outro_pai = true
				objetos_encontrados += 1

		"quadro_sombrio":
			if not quadro_sombrio:
				quadro_sombrio = true
				objetos_encontrados += 1

		"olho_na_parede":
			if not olho_na_parede:
				olho_na_parede = true
				objetos_encontrados += 1

		"urso_empalhado_sangrando":
			if not urso_empalhado_sangrando:
				urso_empalhado_sangrando = true
				objetos_encontrados += 1

		"espelho_estranho":
			if not espelho_estranho:
				espelho_estranho = true
				objetos_encontrados += 1

		"boneca_quebrada":
			if not boneca_quebrada:
				boneca_quebrada = true
				objetos_encontrados += 1

		"ursinho_rasgado":
			if not ursinho_rasgado:
				ursinho_rasgado = true
				objetos_encontrados += 1

		"bilhetes_socorro":
			if not bilhetes_socorro:
				bilhetes_socorro = true
				objetos_encontrados += 1

		"sangue_chao":
			if not sangue_chao:
				sangue_chao = true
				objetos_encontrados += 1

		"objetos_tortura":
			if not objetos_tortura:
				objetos_tortura = true
				objetos_encontrados += 1

		"mesa_jantar":
			if not mesa_jantar:
				mesa_jantar = true
				objetos_encontrados += 1
			
func progresso_coleta():
	return float(objetos_encontrados) / float(total_objetos_coletaveis)
		

func verificar_progresso():

	if etapa == 0:
		avancar_etapa(1)

	elif etapa == 1:
		print("esta na etapa 1")
		if item_fita and item_panela and foto_familia and caderno_lina:

			if objetivos:
				objetivos.get_node("Check").show()
			
			avancar_etapa(2)

	elif etapa == 2:

		print("esta na etapa 2")

		if objetivos == null:
			print("null")
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			print("não null")

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()

			objetivos.get_node("Label").text = "Falar com mãe"

		if caixa_pai:
			print("caixa pai n null")

			avancar_etapa(3)

	elif etapa == 3:
		print("esta na etapa 3")

		if objetivos == null:
			print("null")
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:

			objetivos.show()
			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Label").text = "Falar com mãe"
			

		if falar_mae_etapa3:
			objetivos.get_node("Label").text = "Encontrar Porta"

		if encontrou_porta:
					await get_tree().create_timer(1.0).timeout
					avancar_etapa(4)

		if caixa_pai:
			print("caixa pai n null")
			avancar_etapa(3)

	elif etapa == 4:
		print("esta na etapa 4")

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:

			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Encontrar a chave"

		if chave_porta:

			avancar_etapa(5)


	elif etapa == 5:
		print("esta na etapa 5")

		if objetivos:

			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Abrir a porta"

		if abriu_porta:

			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(6)


	elif etapa == 6:
		print("esta na etapa 6")

		if objetivos:

			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Entrar na porta"

		if porta_outro_mundo:

			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(7)
			
			
	elif etapa == 7:
		print("esta na etapa 7")

		if objetivos == null:
			print("objetivo é null")
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			print("objetivo é true")

			objetivos.show()
			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Explorar a casa"

		if foto_outra_familia and caderno_outra_lina and caixa_outro_pai:
			if objetivos:
				print("pegou os 3 objetos")
				objetivos.get_node("Check").show()

			avancar_etapa(8)


	elif etapa == 8:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com a outra mãe"

		if falar_outra_mae:
			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(9)


	elif etapa == 9:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com o outro pai"

		if falar_outro_pai:
			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(10)


	elif etapa == 10:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com o gato"

		if encontrou_gato:
			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(11)
			
	elif etapa == 11:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Label").text = "Investigar os objetos estranhos"

			print("investigar if")

		if quadro_sombrio \
		and olho_na_parede \
		and urso_empalhado_sangrando \
		and espelho_estranho:

			print("pegou os objetos")

			avancar_etapa(12)


	elif etapa == 12:

		print("etapa 12")

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Label").text = "Investigar o porão"

		print(boneca_quebrada)
		print(ursinho_rasgado)
		print(bilhetes_socorro)
		print(sangue_chao)
		print(objetos_tortura)
		print(mesa_jantar)
		print(entrou_no_porao)

		if entrou_no_porao:
			if boneca_quebrada and \
				ursinho_rasgado and \
				bilhetes_socorro and \
				sangue_chao and \
				objetos_tortura and \
				mesa_jantar:

				print("pegou tudo")

				avancar_etapa(13)


	elif etapa == 13:

		objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Label").text = "Algo está errado..."

		print(avançar_etapa_14)

		if avançar_etapa_14:
			avancar_etapa(14)


	elif etapa == 14:

		objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Label").text = "Fuja! Eles estão vindo!"

		# chama o aviso
		GameManager.mostrar_ajuda.emit()

		# estado do jogo
		pais_perseguem = true
		irmao_jogando_pedra = true

		avancar_etapa(15)


	elif etapa == 15:

		objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()

			objetivos.get_node("Fundo").show()
			objetivos.get_node("Label").show()

			objetivos.get_node("Label").text = "Pedir ajuda ao gato"

		if falou_com_gato_final:
			avancar_etapa(16)
		
	elif etapa == 16:
		if objetivos:
			objetivos.hide()
		GameManager.finalizar_jogo("Final Ruim")
		
		
func mostrar_objetivo_concluido():

	var aviso = get_tree().current_scene.get_node_or_null("CanvasLayer/AvisoObjetivo")

	if aviso == null:
		return

	aviso.text = "✔ Prontinho\nVou levar todas essas coisas até a minha mãe."

	aviso.visible = true

	await get_tree().create_timer(3.0).timeout

	aviso.visible = false

func verificar_lista_completa():

	if item_fita and item_panela and foto_familia and caderno_lina:
		mostrar_objetivo_concluido()
		verificar_progresso()
		var lista = get_tree().current_scene.get_node_or_null("CanvasLayer/Lista")
		if lista:
			lista.hide()
			
func formatar_tempo() -> String:

	var segundos = int(tempo_total)
	var horas = segundos / 3600
	var minutos = (segundos % 3600) / 60
	var seg = segundos % 60

	return "%02d:%02d:%02d" % [horas, minutos, seg]

func finalizar_jogo(final_nome):
	final_alcancado = final_nome
	
func distancia_formatada():
	return str(int(distancia_andada / 10)) + " m"
