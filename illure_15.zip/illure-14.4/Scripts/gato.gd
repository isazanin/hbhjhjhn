extends CharacterBody2D

@export var speed = 130
@export var distancia_minima = 14
@export var offset_atras = Vector2(-20, 12)

var player: CharacterBody2D = null

# =====================================
# CONTROLE
# =====================================
var parado_dialogo = false
var player_perto = false

# =====================================
# ANIMAÇÃO
# =====================================
@onready var sprite = $AnimatedSprite2D

var ultima_direcao = "down"

# =====================================
# READY
# =====================================
func _ready():

	player = get_tree().get_first_node_in_group("player")

	_atualizar_estado_por_etapa(GameManager.etapa)

	if GameManager.has_signal("etapa_mudou"):
		GameManager.etapa_mudou.connect(_on_etapa_mudou)

	# DETECÇÃO
	$Area2D.body_entered.connect(_on_body_entered)
	$Area2D.body_exited.connect(_on_body_exited)


# =====================================
# DETECÇÃO
# =====================================
func _on_body_entered(body):

	if body.is_in_group("player"):
		player_perto = true


func _on_body_exited(body):

	if body.is_in_group("player"):
		player_perto = false


# =====================================
# ETAPA
# =====================================
func _on_etapa_mudou(nova_etapa: int) -> void:
	_atualizar_estado_por_etapa(nova_etapa)


func _atualizar_estado_por_etapa(etapa_atual: int) -> void:
	visible = etapa_atual >= 10


# =====================================
# MOVIMENTO
# =====================================
func _physics_process(delta):

	if GameManager.etapa < 10:

		velocity = Vector2.ZERO

		animar_gato(Vector2.ZERO)

		move_and_slide()

		global_position = global_position.round()

		return


	if player == null:
		return


	# =====================================
	# PARA SE ESTIVER PERTO DO PLAYER
	# =====================================
	if player_perto:

		velocity = Vector2.ZERO

		animar_gato(Vector2.ZERO)

		move_and_slide()

		global_position = global_position.round()

		return


	# =====================================
	# ETAPA 10 = PARADO
	# =====================================
	if GameManager.etapa == 10:

		velocity = Vector2.ZERO

		animar_gato(Vector2.ZERO)

		move_and_slide()

		global_position = global_position.round()

		return


	# =====================================
	# DIÁLOGO GLOBAL
	# =====================================
	if GameManager.em_dialogo or parado_dialogo:

		velocity = Vector2.ZERO

		animar_gato(Vector2.ZERO)

		move_and_slide()

		global_position = global_position.round()

		return


	# =====================================
	# SEGUE O PLAYER
	# =====================================
	var alvo = player.global_position + offset_atras

	var direcao = alvo - global_position

	var distancia = direcao.length()


	if player.velocity.length() > 0:

		if distancia > distancia_minima:

			velocity = velocity.lerp(
				direcao.normalized() * speed,
				0.2
			)

		else:
			velocity = Vector2.ZERO

	else:
		velocity = Vector2.ZERO


	animar_gato(velocity)

	move_and_slide()

	global_position = global_position.round()


# =====================================
# ANIMAÇÃO
# =====================================
func animar_gato(direction):

	# =====================================
	# PARADO
	# =====================================
	if direction == Vector2.ZERO:

		var idle_anim = "idle_" + ultima_direcao

		if sprite.animation != idle_anim:
			sprite.play(idle_anim)

		return


	# =====================================
	# DIREÇÃO
	# =====================================
	if abs(direction.x) > abs(direction.y):

		if direction.x > 0:
			ultima_direcao = "right"
		else:
			ultima_direcao = "left"

	else:

		if direction.y > 0:
			ultima_direcao = "down"
		else:
			ultima_direcao = "up"


	# =====================================
	# WALK
	# =====================================
	var walk_anim = "walk_" + ultima_direcao

	if sprite.animation != walk_anim:
		sprite.play(walk_anim)
