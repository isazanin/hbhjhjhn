extends Node2D

@onready var sprite = $Sprite2D
@onready var bullet_marker = $Sprite2D/Bullet_Marker

@export var bullet_scene: PackedScene


func _process(delta):

	#if not GameManager.irmao_jogando_pedra:
	#	return

	aim()
	shoot()


func aim():

	var mouse_pos = get_global_mouse_position()

	look_at(mouse_pos)

	if mouse_pos.x < global_position.x:
		sprite.flip_v = true
	else:
		sprite.flip_v = false


func shoot():
	if Input.is_action_just_pressed("p2_attack") and bullet_scene:
		print("ATIROU")

		var bullet = bullet_scene.instantiate()
		get_tree().current_scene.add_child(bullet)

		bullet.global_position = global_position

		var dir = (get_global_mouse_position() - global_position).normalized()
		bullet.velocity = dir * 250
