extends Area2D

var velocity: Vector2 = Vector2.ZERO

func _ready():

	body_entered.connect(_on_body_entered)

	await get_tree().create_timer(3.0).timeout
	queue_free()


func _process(delta):

	global_position += velocity * delta


func _on_body_entered(body):

	if body.has_method("tomar_pedra"):

		body.tomar_pedra()

		queue_free()
